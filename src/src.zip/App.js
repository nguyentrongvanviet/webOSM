import React, { useState } from 'react';
import L from 'leaflet';
import axios from 'axios';
import MapView from './MapView';
import './App.css';
import 'leaflet/dist/leaflet.css';

// Fix for default marker icons in react-leaflet
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

let DefaultIcon = L.icon({
  iconUrl: icon,
  shadowUrl: iconShadow,
  iconSize: [25, 41],
  iconAnchor: [12, 41]
});

L.Marker.prototype.options.icon = DefaultIcon;

function App() {
  const [locationName, setLocationName] = useState('');
  const [center, setCenter] = useState([16.0544, 108.2022]); // Default: Da Nang
  const [zoom, setZoom] = useState(13);
  const [pointsOfInterest, setPointsOfInterest] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const searchLocation = async () => {
    if (!locationName.trim()) {
      setError('Vui lòng nhập tên địa điểm');
      return;
    }

    setLoading(true);
    setError('');

    try {
      // Search for the location using Nominatim API
      const searchResponse = await axios.get(
        `https://nominatim.openstreetmap.org/search`,
        {
          params: {
            q: `${locationName}, Vietnam`,
            format: 'json',
            limit: 1,
          },
          headers: {
            'User-Agent': 'VietnamMapApp/1.0'
          }
        }
      );

      if (searchResponse.data.length === 0) {
        setError('Không tìm thấy địa điểm. Vui lòng thử lại.');
        setLoading(false);
        return;
      }

      const location = searchResponse.data[0];
      const lat = parseFloat(location.lat);
      const lon = parseFloat(location.lon);

      setCenter([lat, lon]);
      setZoom(14);

      // Get points of interest around the location using Overpass API
      const overpassQuery = `
        [out:json];
        (
          node["tourism"](around:2000,${lat},${lon});
          node["amenity"="restaurant"](around:2000,${lat},${lon});
          node["amenity"="cafe"](around:2000,${lat},${lon});
          node["shop"](around:2000,${lat},${lon});
          node["historic"](around:2000,${lat},${lon});
        );
        out body 5;
      `;

      const poiResponse = await axios.post(
        'https://overpass-api.de/api/interpreter',
        overpassQuery,
        {
          headers: {
            'Content-Type': 'text/plain'
          }
        }
      );

      const pois = poiResponse.data.elements.map(element => ({
        id: element.id,
        lat: element.lat,
        lon: element.lon,
        name: element.tags.name || 'Không có tên',
        type: element.tags.tourism || element.tags.amenity || element.tags.shop || element.tags.historic || 'Điểm quan tâm',
      }));

      setPointsOfInterest(pois.slice(0, 5));
      setLoading(false);
    } catch (err) {
      console.error('Error:', err);
      setError('Đã xảy ra lỗi khi tìm kiếm. Vui lòng thử lại.');
      setLoading(false);
    }
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      searchLocation();
    }
  };

  return (
    <div className="App">
      <header className="header">
        <h1>🗺️ Bản đồ Việt Nam</h1>
        <p>Tìm kiếm địa điểm và khám phá các điểm quan tâm xung quanh</p>
      </header>

      <div className="search-container">
        <input
          type="text"
          className="search-input"
          placeholder="Nhập tên địa điểm (ví dụ: Hà Nội, Sài Gòn, Đà Nẵng...)"
          value={locationName}
          onChange={(e) => setLocationName(e.target.value)}
          onKeyPress={handleKeyPress}
        />
        <button 
          className="search-button" 
          onClick={searchLocation}
          disabled={loading}
        >
          {loading ? 'Đang tìm...' : 'Tìm kiếm'}
        </button>
      </div>

      {error && <div className="error-message">{error}</div>}

      {pointsOfInterest.length > 0 && (
        <div className="poi-count">
          Tìm thấy {pointsOfInterest.length} điểm quan tâm
        </div>
      )}

      <div className="map-container">
        <MapView 
          center={center}
          zoom={zoom}
          pointsOfInterest={pointsOfInterest}
        />
      </div>

      {pointsOfInterest.length > 0 && (
        <div className="poi-list">
          <h2>Các điểm quan tâm</h2>
          <ul>
            {pointsOfInterest.map((poi) => (
              <li key={poi.id}>
                <strong>{poi.name}</strong> - {poi.type}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

export default App;
